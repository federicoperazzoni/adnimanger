package jena.adni.constants;

public interface Constants {

	public final static String PHASE_ADNI1 = "ADNI1";
	public final static String PHASE_ADNIGO = "ADNIGO";
	public final static String PHASE_ADNI2 = "ADNI2";
	public final static String PHASE_ADNI3 = "ADNI3";
}
