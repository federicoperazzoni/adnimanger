package jena.adni.bean;

public class FAQBean extends ADNIBean {

	private String FAQFinance;
	private String FAQSource;
	private String FAQForm;
	private String FAQShop;
	private String FAQGame;
	private String FAQBevarege;
	private String FAQMeal;
	private String FAQEvent;
	private String FAQTv;
	private String FAQRem;
	private String FAQTravel;
	private String FAQTotal;
	
	public String getFAQTotal() {
		return FAQTotal;
	}
	public void setFAQTotal(String fAQTotal) {
		FAQTotal = fAQTotal;
	}
	public String getFAQTravel() {
		return FAQTravel;
	}
	public void setFAQTravel(String fAQTravel) {
		FAQTravel = fAQTravel;
	}
	public String getFAQRem() {
		return FAQRem;
	}
	public void setFAQRem(String fAQRem) {
		FAQRem = fAQRem;
	}
	public String getFAQTv() {
		return FAQTv;
	}
	public void setFAQTv(String fAQTv) {
		FAQTv = fAQTv;
	}
	public String getFAQEvent() {
		return FAQEvent;
	}
	public void setFAQEvent(String fAQEvent) {
		FAQEvent = fAQEvent;
	}
	public String getFAQMeal() {
		return FAQMeal;
	}
	public void setFAQMeal(String fAQMeal) {
		FAQMeal = fAQMeal;
	}
	public String getFAQBevarege() {
		return FAQBevarege;
	}
	public void setFAQBevarege(String fAQBevarege) {
		FAQBevarege = fAQBevarege;
	}
	public String getFAQGame() {
		return FAQGame;
	}
	public void setFAQGame(String fAQGame) {
		FAQGame = fAQGame;
	}
	public String getFAQShop() {
		return FAQShop;
	}
	public void setFAQShop(String fAQShop) {
		FAQShop = fAQShop;
	}
	public String getFAQForm() {
		return FAQForm;
	}
	public void setFAQForm(String fAQForm) {
		FAQForm = fAQForm;
	}
	public String getFAQSource() {
		return FAQSource;
	}
	public void setFAQSource(String fAQSource) {
		FAQSource = fAQSource;
	}
	public String getFAQFinance() {
		return FAQFinance;
	}
	public void setFAQFinance(String fAQFinance) {
		FAQFinance = fAQFinance;
	}
}
