package jena.adni.bean;

public class ADNIBean {

	private SubjectDataBean subjectDataBean;

	public SubjectDataBean getSubjectDataBean() {
		return subjectDataBean;
	}

	public void setSubjectDataBean(SubjectDataBean subjectDataBean) {
		this.subjectDataBean = subjectDataBean;
	}
}
