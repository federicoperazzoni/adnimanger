package jena.adni.bean;

public class ADNIBean {

	private SubjectDataBean subjectDataBean;
	private String phase;

	public SubjectDataBean getSubjectDataBean() {
		return subjectDataBean;
	}

	public void setSubjectDataBean(SubjectDataBean subjectDataBean) {
		this.subjectDataBean = subjectDataBean;
	}

	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}
}
